# BRCA1 DNA Sequence Analysis

An intermediate-level Python bioinformatics project for exploring the human **BRCA1** reference transcript. It calculates sequence statistics, GC content, sliding-window GC content, reverse complement, ORFs, translated ORFs, motif locations, and differences between two same-length sequences.

> **Important:** This is an educational sequence-analysis pipeline, not a clinical variant interpretation tool. A detected difference is not automatically disease-causing. Do not use this project to make medical decisions.

## Biological background

BRCA1 (breast cancer type 1 susceptibility) is a tumor-suppressor gene involved in maintaining genomic stability and DNA repair. This project starts with the reviewed RefSeq transcript **NM_007294.4** (human BRCA1 transcript variant 1; mRNA, 7,088 nt in the NCBI record accessed when this project was prepared).

- NCBI RefSeq: https://www.ncbi.nlm.nih.gov/nuccore/NM_007294.4
- NCBI Gene (Gene ID 672): https://www.ncbi.nlm.nih.gov/gene/672

## Project structure

```text
BRCA1_DNA_Sequence_Analysis/
├── data/
│   ├── sample_brca1_excerpt.fasta
│   └── demo_variant.fasta
├── results/                  # generated output files
├── src/
│   └── brca1_analysis.py
├── requirements.txt
├── .gitignore
└── README.md
```

## 1. Set up

Python 3.9+ is recommended.

```bash
# Create and activate a virtual environment (Windows PowerShell)
python -m venv .venv
.venv\Scripts\Activate.ps1

# macOS/Linux:
# python3 -m venv .venv
# source .venv/bin/activate

pip install -r requirements.txt
```

## 2. Run using the included sample data

```bash
python src/brca1_analysis.py --input data/sample_brca1_excerpt.fasta --outdir results
```

This sample is a short BRCA1 transcript excerpt for testing the workflow. It is not the complete gene/transcript.

## 3. Download the full reference transcript from NCBI

The script can retrieve the current sequence record by accession using NCBI Entrez:

```bash
python src/brca1_analysis.py --fetch NM_007294.4 --outdir results
```

For responsible use of NCBI E-utilities, add your email address:

```bash
python src/brca1_analysis.py --fetch NM_007294.4 --email your_email@example.com --outdir results
```

The downloaded FASTA is saved in `results/`. An internet connection is required. NCBI may update sequence records over time; record the accession/version used in your report.

## 4. Compare a second sequence (demonstration only)

```bash
python src/brca1_analysis.py --input data/sample_brca1_excerpt.fasta --compare data/demo_variant.fasta --outdir results
```

`demo_variant.fasta` contains an **artificially altered teaching example**, not a real patient variant and not a clinically classified BRCA1 mutation. The comparison reports sequence differences only.

## 5. Outputs

After running, check `results/`:

| File | Description |
|---|---|
| `sequence_summary.csv` | Length, A/T/G/C/N counts and GC percentage |
| `gc_windows.csv` | GC percentage in sliding windows |
| `motif_hits.csv` | Positions of selected motifs (0-based and 1-based) |
| `orfs.fasta` | Candidate ORFs found in six reading frames |
| `gc_content.png` | Sliding-window GC plot |
| `nucleotide_counts.png` | Nucleotide composition plot |
| `sequence_comparison.csv` | Differences when `--compare` is used |

ORFs found in an mRNA transcript are computational candidates. They are not necessarily biologically expressed proteins.

## Methods

1. Parse FASTA and validate nucleotide symbols.
2. Calculate nucleotide composition and GC percentage.
3. Calculate GC content in fixed-width sliding windows.
4. Generate reverse-complement sequence.
5. Search for user-selected motifs.
6. Scan all three forward and three reverse-complement reading frames for start-to-stop ORFs.
7. Translate candidate ORFs with Biopython.
8. Optionally compare two sequences of equal length and report mismatches.

## Suggested extensions (to make it more intermediate/advanced)

- Add variant annotation using ClinVar or Ensembl VEP, with careful provenance tracking.
- Compare BRCA1 with BRCA2 or orthologous sequences.
- Add BLAST search and interpret sequence similarity.
- Annotate exon/CDS features from GenBank rather than treating the full transcript as coding DNA.
- Add unit tests with `pytest` and a GitHub Actions workflow.
- Build a Streamlit dashboard for interactive exploration.

## Limitations and interpretation

- The reference fetched here is an **mRNA transcript**, not the full genomic BRCA1 locus. It does not include all introns and regulatory DNA.
- GC content, motifs, and ORFs are descriptive sequence features; none diagnoses breast cancer or predicts individual risk.
- The optional comparison only reports raw differences. It does not normalize HGVS variants, determine pathogenicity, or account for transcript/genome coordinate conversions.
- For research-grade variant interpretation, use validated pipelines and authoritative resources such as ClinVar, ENIGMA, and current clinical guidelines.

## Citation / data provenance

Reference sequence: NCBI RefSeq **NM_007294.4**, *Homo sapiens BRCA1 DNA repair associated (BRCA1), transcript variant 1, mRNA*. Always verify the accession version and retrieval date when reproducing the analysis.

## License

Code: MIT License (you may add a `LICENSE` file before publishing). NCBI sequence data remain subject to NCBI's data-use policies.
