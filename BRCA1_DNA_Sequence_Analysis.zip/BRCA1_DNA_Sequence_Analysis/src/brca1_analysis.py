#!/usr/bin/env python3
"""Educational BRCA1 transcript sequence analysis pipeline."""

from __future__ import annotations
import argparse
from pathlib import Path
from collections import Counter
from Bio import SeqIO
from Bio.Seq import Seq
from Bio import Entrez
import pandas as pd
import matplotlib.pyplot as plt

VALID = set("ACGTN")
MOTIFS = ["AATAAA", "GT", "AG"]


def load_fasta(path: Path):
    records = list(SeqIO.parse(str(path), "fasta"))
    if not records:
        raise ValueError(f"No FASTA records found in {path}")
    record = records[0]
    sequence = str(record.seq).upper().replace("U", "T")
    invalid = sorted(set(sequence) - VALID)
    if invalid:
        raise ValueError(f"Invalid nucleotide symbols: {invalid}")
    if not sequence:
        raise ValueError("Sequence is empty")
    return record.id, sequence


def fetch_ncbi(accession: str, output: Path, email: str | None = None):
    Entrez.email = email or "researcher@example.com"
    with Entrez.efetch(db="nuccore", id=accession, rettype="fasta", retmode="text") as handle:
        fasta_text = handle.read()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(fasta_text, encoding="utf-8")
    return output


def sequence_stats(sequence: str):
    counts = Counter(sequence)
    length = len(sequence)
    gc = ((counts["G"] + counts["C"]) / length * 100) if length else 0
    row = {
        "length_bp": length,
        "A": counts["A"], "T": counts["T"],
        "G": counts["G"], "C": counts["C"], "N": counts["N"],
        "GC_percent": round(gc, 3),
    }
    return row


def gc_windows(sequence: str, window: int = 100, step: int = 50):
    rows = []
    for start in range(0, max(1, len(sequence) - window + 1), step):
        fragment = sequence[start:start + window]
        if not fragment:
            continue
        valid = sum(1 for base in fragment if base in "ACGT")
        gc = sum(1 for base in fragment if base in "GC")
        percent = gc / valid * 100 if valid else 0
        rows.append({"start_0based": start, "end_0based_exclusive": start + len(fragment),
                     "GC_percent": round(percent, 3)})
    return rows


def find_motifs(sequence: str, motifs=MOTIFS):
    hits = []
    for motif in motifs:
        motif = motif.upper().replace("U", "T")
        start = 0
        while True:
            index = sequence.find(motif, start)
            if index == -1:
                break
            hits.append({"motif": motif, "start_0based": index,
                         "start_1based": index + 1, "end_1based": index + len(motif)})
            start = index + 1
    return hits


def find_orfs(sequence: str, min_aa: int = 30):
    """Find ATG-to-in-frame-stop ORFs in all six frames."""
    results = []
    for strand, seq in [("+", sequence), ("-", str(Seq(sequence).reverse_complement()))]:
        for frame in range(3):
            for start in range(frame, len(seq) - 2, 3):
                if seq[start:start + 3] != "ATG":
                    continue
                for stop in range(start + 3, len(seq) - 2, 3):
                    codon = seq[stop:stop + 3]
                    if codon in {"TAA", "TAG", "TGA"}:
                        coding = seq[start:stop + 3]
                        aa = str(Seq(coding).translate(to_stop=True))
                        if len(aa) >= min_aa:
                            results.append({
                                "strand": strand, "frame": frame,
                                "start_0based_in_oriented_sequence": start,
                                "end_0based_exclusive_in_oriented_sequence": stop + 3,
                                "length_nt": len(coding), "length_aa": len(aa),
                                "nucleotide_sequence": coding,
                                "protein_sequence": aa,
                            })
                        break
    return results


def compare_sequences(reference: str, query: str):
    if len(reference) != len(query):
        raise ValueError(
            "This simple comparison requires equal-length sequences. "
            "Use an alignment tool for insertions/deletions."
        )
    rows = []
    for i, (ref, alt) in enumerate(zip(reference, query)):
        if ref != alt:
            rows.append({"position_1based": i + 1, "reference": ref, "alternate": alt,
                         "change": f"{ref}>{alt}"})
    return rows


def write_outputs(name, sequence, outdir: Path, compare_path: Path | None):
    outdir.mkdir(parents=True, exist_ok=True)
    stats = sequence_stats(sequence)
    pd.DataFrame([{"record": name, **stats}]).to_csv(outdir / "sequence_summary.csv", index=False)

    windows = gc_windows(sequence)
    pd.DataFrame(windows).to_csv(outdir / "gc_windows.csv", index=False)

    motifs = find_motifs(sequence)
    pd.DataFrame(motifs, columns=["motif", "start_0based", "start_1based", "end_1based"]).to_csv(
        outdir / "motif_hits.csv", index=False
    )

    orfs = find_orfs(sequence)
    with (outdir / "orfs.fasta").open("w", encoding="utf-8") as handle:
        for i, orf in enumerate(orfs, 1):
            handle.write(f">ORF_{i}|strand={orf['strand']}|frame={orf['frame']}|aa={orf['length_aa']}\n")
            handle.write(orf["protein_sequence"] + "\n")

    counts = {base: stats[base] for base in "ATGCN"}
    plt.figure(figsize=(7, 4))
    plt.bar(counts.keys(), counts.values())
    plt.title("BRCA1 sequence nucleotide composition")
    plt.xlabel("Nucleotide")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(outdir / "nucleotide_counts.png", dpi=200)
    plt.close()

    if windows:
        frame = pd.DataFrame(windows)
        plt.figure(figsize=(9, 4))
        plt.plot(frame["start_0based"] + 1, frame["GC_percent"], marker="o", markersize=3)
        plt.title("BRCA1 sliding-window GC content")
        plt.xlabel("Window start (1-based)")
        plt.ylabel("GC content (%)")
        plt.tight_layout()
        plt.savefig(outdir / "gc_content.png", dpi=200)
        plt.close()

    if compare_path:
        _, query = load_fasta(compare_path)
        differences = compare_sequences(sequence, query)
        pd.DataFrame(differences, columns=["position_1based", "reference", "alternate", "change"]).to_csv(
            outdir / "sequence_comparison.csv", index=False
        )
        print(f"Sequence differences found: {len(differences)}")
    print(f"Analysis complete. Results saved in: {outdir.resolve()}")
    print(f"Length: {stats['length_bp']} nt | GC: {stats['GC_percent']}% | ORFs >=30 aa: {len(orfs)}")


def main():
    parser = argparse.ArgumentParser(description="Analyze a BRCA1 FASTA sequence.")
    parser.add_argument("--input", type=Path, help="Input FASTA file")
    parser.add_argument("--fetch", metavar="ACCESSION", help="Fetch a RefSeq accession from NCBI")
    parser.add_argument("--email", help="Email for NCBI Entrez identification")
    parser.add_argument("--compare", type=Path, help="Optional equal-length FASTA for simple comparison")
    parser.add_argument("--outdir", type=Path, default=Path("results"))
    args = parser.parse_args()

    if args.fetch:
        fasta_path = args.outdir / f"{args.fetch.replace('.', '_')}.fasta"
        fetch_ncbi(args.fetch, fasta_path, args.email)
        input_path = fasta_path
    elif args.input:
        input_path = args.input
    else:
        parser.error("Provide --input PATH or --fetch ACCESSION")

    name, sequence = load_fasta(input_path)
    write_outputs(name, sequence, args.outdir, args.compare)


if __name__ == "__main__":
    main()
